// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

// This is the Font tool for the Irrlicht Engine. It only runs and compiles
// with windows.
// I hacked this program within a few minutes, so the code is currently not 
// documentated and very C.

#include "stdafx.h"
#include "resource.h"
#include "stdio.h"
#include "stdlib.h"

struct SCharData
{
	wchar_t character;
	int cwidth;
	int cheight;
	int askiiCode;

	int posX;
	int posY;
	int abcA;
	int abcB;
	int abcC;
};


int CALLBACK EnumFamCallBack(CONST LOGFONT *lplf, CONST TEXTMETRIC *lptm, DWORD FontType, LPARAM lpData) 
{ 
	SendDlgItemMessage ((HWND)lpData, IDC_LIST1, LB_ADDSTRING, 0, (LONG)lplf->lfFaceName); 
	return 1;
}


int GetFontSize(HWND hWnd)
{
	int sizeSel = 10;
	char sz[100]="";
	GetWindowText(GetDlgItem(hWnd,IDC_EDIT_SIZE),sz,100);
	//SendDlgItemMessage(hWnd, IDC_LIST2, LB_GETCURSEL, 0, 0);
	sizeSel=atol(sz);
	if(sz<=0){
		sizeSel=10;
	}
	return sizeSel;
}

void updateFontPreview(HWND hWnd)
{
	int sel = SendDlgItemMessage(hWnd, IDC_LIST1, LB_GETCURSEL, 0, 0);
	int bold = SendDlgItemMessage(hWnd, IDC_CHECK1, BM_GETCHECK, 0, 0);
	int italic = SendDlgItemMessage(hWnd, IDC_CHECK2, BM_GETCHECK, 0, 0);
	int iCharset=0;
	char szch[100]="";
	GetWindowText(GetDlgItem(hWnd,IDC_EDIT_CH),szch,100);
	iCharset=atol(szch);
	
	if (sel != LB_ERR)
	{
		char str[1024]; 

		int fontSize = GetFontSize(hWnd);

		SendDlgItemMessage(hWnd, IDC_LIST1, LB_GETTEXT, sel, (LPARAM) (LPCTSTR)str);

		HDC dc = GetDC(hWnd);
		//BALTIC_CHARSET
		HFONT font = CreateFont(
			-MulDiv(fontSize, GetDeviceCaps(dc, LOGPIXELSY), 72),
			0,0,0,
			bold ? FW_BOLD : 0,
			italic,
			0,0,iCharset,0,0,0,0,
			str);

		ReleaseDC(hWnd, dc);

		RECT r;
		HWND preview = GetDlgItem(hWnd, IDC_PREVIEW);
		GetClientRect(preview, &r);

		LOGBRUSH lbrush;
		lbrush.lbColor = GetSysColor(COLOR_3DFACE);
		lbrush.lbHatch = 0;
		lbrush.lbStyle = BS_SOLID;
		
		HBRUSH brush = CreateBrushIndirect(&lbrush);
		HPEN pen = CreatePen(PS_NULL, 0, 0);

		dc = GetDC(preview);

		HGDIOBJ oldfont = SelectObject(dc, font);
		HGDIOBJ oldpen = SelectObject(dc, pen);
		HGDIOBJ oldbrush = SelectObject(dc, brush);

		char text[1000]= "ABC��� abc��� 12345";
		GetWindowText(GetDlgItem(hWnd,IDC_EDIT_TEXT),text,100);
		if(strlen(text)==0){
			strcpy(text,str);
		}

		SetBkMode(dc, OPAQUE);
		SetBkColor(dc, GetSysColor(COLOR_3DFACE));
		Rectangle(dc, 0,0, r.right, r.bottom);

		DrawText(dc, text, strlen(text), &r, DT_VCENTER | DT_CENTER | DT_SINGLELINE);

		SelectObject(dc, oldfont);
		SelectObject(dc, oldpen);
		SelectObject(dc, oldbrush);

		ReleaseDC(preview, dc);

		DeleteObject(font);
		DeleteObject(brush);
		DeleteObject(pen);
	}
}


void FillFontList(HWND hWnd)
{
	// Fill list with font names

	SendDlgItemMessage(hWnd, IDC_LIST1, LB_RESETCONTENT, 0, 0); 
	HDC dc = GetDC(hWnd);
	EnumFonts(dc, 0, &EnumFamCallBack, (LPARAM)hWnd);
	ReleaseDC(hWnd, dc);

	SendDlgItemMessage (hWnd, IDC_LIST1, LB_SETCURSEL, 0, 0);

	// Fill texture size list

	int tc[] = {64,128,256,512,1024,2048,0};
	char buf[256];
	for (int t=0; tc[t] != 0; ++t)
	{
		sprintf(buf, "%d pixels width", tc[t]);
		SendDlgItemMessage (hWnd, IDC_COMBO1, CB_ADDSTRING, 0, (LONG)buf);
	}

	SendDlgItemMessage (hWnd, IDC_COMBO1, CB_SETCURSEL, 3, 0);
	SetWindowText(GetDlgItem(hWnd,IDC_EDIT_CH),"204/238");
	SetWindowText(GetDlgItem(hWnd,IDC_EDIT_SIZE),"24");
	//GetDlgItem(hWnd,IDC_EDIT_SIZE)	IDC_CHECK_XML
}



inline int getTextureSizeFromSurfaceSize(int size)
{
	int ts = 0x01;
	while(ts < size)
		ts <<= 1;

	return ts;
}

LPBITMAPINFO CreateBitmapInfoStruct(HWND hwnd, HBITMAP& hBmp)
{ 
    BITMAP bmp; 
    PBITMAPINFO pbmi; 
    WORD    cClrBits; 
	
    // Retrieve the bitmap color format, width, and height. 
	int iOutBytes=GetObject(hBmp, sizeof(BITMAP), 0);
	int iBitmapSize=sizeof(BITMAP);
    if (!GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bmp)){
		DWORD dwErr=GetLastError();
        AfxMessageBox("Error creating wallpaper (GetObject)");
		return NULL;
	}
	
    // Convert the color format to a count of bits. 
    cClrBits = (WORD)(bmp.bmPlanes * bmp.bmBitsPixel); 
    if (cClrBits == 1) 
        cClrBits = 1; 
    else if (cClrBits <= 4) 
        cClrBits = 4; 
    else if (cClrBits <= 8) 
        cClrBits = 8; 
    else if (cClrBits <= 16) 
        cClrBits = 16; 
    else if (cClrBits <= 24) 
        cClrBits = 24; 
    else cClrBits = 32; 
	
    // Allocate memory for the BITMAPINFO structure. (This structure 
    // contains a BITMAPINFOHEADER structure and an array of RGBQUAD 
    // data structures.) 
	
	if (cClrBits != 24) 
		pbmi = (PBITMAPINFO) LocalAlloc(LPTR, 
		sizeof(BITMAPINFOHEADER) + 
		sizeof(RGBQUAD) * (1<< cClrBits)); 
	
	// There is no RGBQUAD array for the 24-bit-per-pixel format. 
	
	else 
		pbmi = (PBITMAPINFO) LocalAlloc(LPTR, 
		sizeof(BITMAPINFOHEADER)); 
	
    // Initialize the fields in the BITMAPINFO structure. 
	
    pbmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER); 
    pbmi->bmiHeader.biWidth = bmp.bmWidth; 
    pbmi->bmiHeader.biHeight = bmp.bmHeight; 
    pbmi->bmiHeader.biPlanes = bmp.bmPlanes; 
    pbmi->bmiHeader.biBitCount = bmp.bmBitsPixel; 
    if (cClrBits < 24) 
        pbmi->bmiHeader.biClrUsed = (1<<cClrBits); 
	
    // If the bitmap is not compressed, set the BI_RGB flag. 
    pbmi->bmiHeader.biCompression = BI_RGB; 
	
    // Compute the number of bytes in the array of color 
    // indices and store the result in biSizeImage. 
    // For Windows NT, the width must be DWORD aligned unless 
    // the bitmap is RLE compressed. This example shows this. 
    // For Windows 95/98/Me, the width must be WORD aligned unless the 
    // bitmap is RLE compressed.
    pbmi->bmiHeader.biSizeImage = ((pbmi->bmiHeader.biWidth * cClrBits +31) & ~31) /8
		* pbmi->bmiHeader.biHeight; 
    // Set biClrImportant to 0, indicating that all of the 
    // device colors are important. 
	pbmi->bmiHeader.biClrImportant = 0; 
	return pbmi; 
}

class CDesktopDC
{
public:
	CDC* dc;
	CDesktopDC()
	{
		dc=new CDC();
		dc->CreateDC("DISPLAY", NULL, NULL, NULL);
	}
	CDC* operator&()
	{
		return dc;
	}
	CDC* operator->()
	{
		return dc;
	}
	operator HDC()
	{
		return dc->GetSafeHdc();
	}
	~CDesktopDC()
	{
		delete dc;
	}
};


BOOL CreateBMPFile(HWND hwnd, const char* pszFile, PBITMAPINFO pbi, HBITMAP hBMP) 
{ 
	if(pszFile==NULL || strlen(pszFile)==0){
		AfxMessageBox("Error creating wallpaper (Empty file name)");
		return FALSE;
	}
	//
	HANDLE hf=NULL;
    BITMAPFILEHEADER hdr;
    PBITMAPINFOHEADER pbih=NULL;
    LPBYTE lpBits=NULL;
    DWORD dwTotal=0;
    DWORD cb=0;
    BYTE *hp=NULL;
    DWORD dwTmp=0;
	BOOL bRes=TRUE;
	try{
		pbih = (PBITMAPINFOHEADER) pbi; 
		lpBits = (LPBYTE) GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, pbih->biSizeImage);
		if (!lpBits){
			AfxMessageBox("Error creating wallpaper (GlobalAlloc failed)");
			throw 0;
		}
		// Retrieve the color table (RGBQUAD array) and the bits 
		// (array of palette indices) from the DIB. 
		CDC pDC;
		CDesktopDC dcDesk;
		pDC.CreateCompatibleDC(&dcDesk);
		if (!GetDIBits(pDC.GetSafeHdc(), hBMP, 0, (WORD) pbih->biHeight, lpBits, pbi, 
			DIB_RGB_COLORS)){
			AfxMessageBox("Error creating wallpaper (GetDIBBitsFailed)");
			throw 0;
		}
		// Create the .BMP file. 
		hf = CreateFile(pszFile, 
			/*GENERIC_READ | */GENERIC_WRITE, 
			(DWORD) 0, 
			NULL, 
			CREATE_ALWAYS, 
			FILE_ATTRIBUTE_NORMAL, 
			(HANDLE) NULL); 
		if (hf == INVALID_HANDLE_VALUE){
			CString sErr;
			sErr.Format("Error creating wallpaper! File: %s (0x%X)",pszFile,GetLastError());
			AfxMessageBox(sErr);
			throw 0;
		}
		hdr.bfType = 0x4d42;        // 0x42 = "B" 0x4d = "M" 
		// Compute the size of the entire file. 
		hdr.bfSize = (DWORD) (sizeof(BITMAPFILEHEADER) + 
			pbih->biSize + pbih->biClrUsed 
			* sizeof(RGBQUAD) + pbih->biSizeImage); 
		hdr.bfReserved1 = 0; 
		hdr.bfReserved2 = 0; 
		// Compute the offset to the array of color indices. 
		hdr.bfOffBits = (DWORD) sizeof(BITMAPFILEHEADER) + 
			pbih->biSize + pbih->biClrUsed 
			* sizeof (RGBQUAD); 
		// Copy the BITMAPFILEHEADER into the .BMP file. 
		if (!WriteFile(hf, (LPVOID) &hdr, sizeof(BITMAPFILEHEADER), 
			(LPDWORD) &dwTmp,  NULL)){
			AfxMessageBox("Error creating wallpaper (WriteFile of header failed)");
			throw 0;
		}
		// Copy the BITMAPINFOHEADER and RGBQUAD array into the file. 
		if (!WriteFile(hf, (LPVOID) pbih, sizeof(BITMAPINFOHEADER) 
			+ pbih->biClrUsed * sizeof (RGBQUAD), 
			(LPDWORD) &dwTmp, ( NULL))){
			AfxMessageBox("Error creating wallpaper (WriteFile of rgb quad failed)");
			throw 0;
		}
		// Copy the array of color indices into the .BMP file. 
		dwTotal = cb = pbih->biSizeImage; 
		hp = lpBits; 
		if (!WriteFile(hf, (LPSTR) hp, (int) cb, (LPDWORD) &dwTmp,NULL)){
			CString sErr;
			sErr.Format("Error creating wallpaper (WriteFile of color indices failed - 0x%X)",GetLastError());
			AfxMessageBox(sErr);
			throw 0;
		}
		// Close the .BMP file. 
		if (!CloseHandle(hf)){
			AfxMessageBox("Error creating wallpaper (Close handle failed)");
			throw 0;
		}
	}catch(...){
		bRes=FALSE;
	}
    // Free memory. 
	if(lpBits){
		VERIFY(::GlobalFree((HGLOBAL)lpBits)==NULL);
	}
	return bRes;
}



BOOL SaveBitmapToDisk(HBITMAP& hbmOutImage, const char* szFile, HWND hParent)
{
	if(!hbmOutImage){
		return FALSE;
	}
	hParent=hParent?hParent:(::GetDesktopWindow());
	PBITMAPINFO pBMPInfo=CreateBitmapInfoStruct(hParent, hbmOutImage);
	if(pBMPInfo==NULL){
		AfxMessageBox("Error creating wallpaper bitmap info struct!");
		return FALSE;
	}
	CreateBMPFile(hParent, szFile, pBMPInfo, hbmOutImage);
	LocalFree(pBMPInfo);
	return TRUE;
}

CString toString(const char* szFormat,...)
{
	va_list vaList;
	va_start(vaList,szFormat);
	CString sBuffer;
	sBuffer.FormatV(szFormat,vaList);
	va_end (vaList);
	return sBuffer;
}

BOOL SaveFile(const char* sStartDir, const char* sFileContent)
{
	//PreparePathForWrite(sStartDir);
	FILE* m_pFile=fopen(sStartDir,"w+b");
	if(!m_pFile){
		return FALSE;
	}
	DWORD nRead=fwrite(sFileContent,sizeof(char),strlen(sFileContent),m_pFile);
	fclose(m_pFile);
	m_pFile=NULL;
	return 1;
}

wchar_t szUnusedChars[]=L"";
BOOL isUnused(int iCharset, wchar_t c)
{
	if(!c){
		return 1;
	}
	USES_CONVERSION;
	wchar_t temp[2]={0};
	temp[0]=c;
	CString cas=W2A(temp);
	unsigned long ca=cas[0];
	if(iCharset==204)
	{
		if(ca>(unsigned long)'~' && ca<(unsigned long)'�'){
			return 1;
		}
	}
	if(wcschr(szUnusedChars,c)!=0){
		return 1;
	}
	return 0;
}

void copyFontToClipBoard(HWND hWnd, int lastChar)
{
	BOOL bXml=1;
	CString sXML;
	sXML="<font>\n";
	int surfaceSel = SendDlgItemMessage(hWnd, IDC_COMBO1, CB_GETCURSEL, 0, 0);
	int sel = SendDlgItemMessage(hWnd, IDC_LIST1, LB_GETCURSEL, 0, 0);	
	int bold = SendDlgItemMessage(hWnd, IDC_CHECK1, BM_GETCHECK, 0, 0);
	int italic = SendDlgItemMessage(hWnd, IDC_CHECK2, BM_GETCHECK, 0, 0);
	char szGa[100]="";
	GetWindowText(GetDlgItem(hWnd,IDC_EDIT_GAP),szGa,100);
	int gapx = atol(szGa);
	GetWindowText(GetDlgItem(hWnd,IDC_EDIT_GAP2),szGa,100);
	int gapy = atol(szGa);
	if(strlen(szGa)==0){
		gapy=gapx;
	}
	GetWindowText(GetDlgItem(hWnd,IDC_EDIT_GAP3),szGa,100);
	int gapr=atol(szGa);
	GetWindowText(GetDlgItem(hWnd,IDC_EDIT_GAP4),szGa,100);
	int gapb=atol(szGa);
	int iCharset=0;
	char szch[100]="";
	GetWindowText(GetDlgItem(hWnd,IDC_EDIT_CH),szch,100);
	iCharset=atol(szch);
	
	if (sel == LB_ERR || surfaceSel == CB_ERR)
		return;

	int i;
	int firstChar = 32;
	int characterCount = lastChar - firstChar;
	SCharData *asciiTable = new SCharData[characterCount];
	wchar_t* testString = new wchar_t[characterCount + 1];
	DWORD* testStringCodes = new DWORD[characterCount + 1]; 
	USES_CONVERSION;
	char sz[2]="";
	for (i=0; i<characterCount; ++i){
		sz[0]=char(i + firstChar);
		WCHAR* wct=new WCHAR(10);//A2W(sz);
		if(iCharset==204)
		{
			wct=A2W(sz);
		}else{
			MultiByteToWideChar(1252,0,sz,-1,wct,wcslen(wct)*sizeof(WCHAR));
		}
		int isu=isUnused(iCharset,wct[0]);
		testString[i] = wct[0];
		testStringCodes[i] = i + firstChar;
		if(iCharset==204 && sz[0]=='�'){//��� ��� ���������
			characterCount=i+1;
			break;
		}
	}

	testString[characterCount] = 0;

	// We use the font render preview area as dc

	HWND preview = GetDlgItem(hWnd, IDC_PREVIEW);
	HDC dc = GetDC(preview);

	char str[1024];

	int fontSize = GetFontSize(hWnd);

	SendDlgItemMessage(hWnd, IDC_COMBO1, CB_GETLBTEXT, surfaceSel, (LPARAM) (LPCTSTR)str);
	int surfaceWidth = atoi(str);

	SendDlgItemMessage(hWnd, IDC_LIST1, LB_GETTEXT, sel, (LPARAM) (LPCTSTR)str);

	HFONT font = CreateFont(
			-MulDiv(fontSize, GetDeviceCaps(dc, LOGPIXELSY), 72),
			0,0,0,
			bold ? FW_BOLD : 0,
			italic,
			0,0,iCharset,0,0,0,0,
			str);
	char szTextureName[256]={0};
	
	GetWindowText(GetDlgItem(hWnd,IDC_EDIT_FNT),szTextureName,100);
	if(szTextureName[0]==0)
	{
		sprintf(szTextureName,"fnt%08X",GetTickCount());
	}
	sXML+=toString("<texture>%s.png</texture>\n",szTextureName);
	sXML+=toString("<face>%s</face>\n",str);
	sXML+=toString("<charset>%i</charset>\n",iCharset);
	sXML+=toString("<size>%i</size>\n",fontSize);
	sXML+=toString("<bold>%i</bold>\n",bold);
	sXML+=toString("<italic>%i</italic>\n",italic);
	sXML+=toString("<texture-width>%i</texture-width>\n",surfaceWidth);
	sXML+=toString("<gaps l='%i' t='%i r='%i' b='%i'/>\n",gapx,gapy,gapr,gapb);
	sXML+=toString("<scale x='1.0' y='1.0' total='1.0' lineh='1.0' />\n");
	HGDIOBJ oldfont = SelectObject(dc, font);

	// calculate text extents.

	SIZE size;
	size.cx = 0;
	size.cy = 0;
	int posx = 0;
	int posy = 1;
	for (i=0; i<characterCount; ++i)
	{
		// ��������� ������/������
		GetTextExtentPoint32W(dc, &testString[i], 1, &size);
		
		ABC charw;
		BOOL bW=GetCharABCWidths(dc, (UINT)testString[i],(UINT)testString[i],&charw);
		int iABCWi=abs(charw.abcA)+abs(charw.abcB);
		size.cx=max(size.cx,iABCWi);
		size.cx+=gapx+gapr;
		size.cy+=gapy+gapb;
		int isu=isUnused(iCharset,testString[i]);
		if(isu>0){
			size.cx=3;
		}
		size.cx+=1;
		


		if (posx + size.cx > surfaceWidth)
		{
			posx = 0;
			posy += size.cy+1;
		}
		asciiTable[i].abcA = charw.abcA;
		asciiTable[i].abcC = charw.abcC;
		asciiTable[i].abcB = charw.abcB;
		asciiTable[i].posX = posx;
		asciiTable[i].posY = posy;
		asciiTable[i].askiiCode = testStringCodes[i];
		asciiTable[i].character = testString[i];
		asciiTable[i].cwidth = size.cx;
		asciiTable[i].cheight = size.cy;		

		posx += size.cx;
	}

	int surfaceHeight = asciiTable[characterCount-1].posY + asciiTable[characterCount-1].cheight + 1;

	surfaceHeight = getTextureSizeFromSurfaceSize(surfaceHeight);

	// draw characters

	HBITMAP bmp = CreateCompatibleBitmap(dc, surfaceWidth, surfaceHeight);
	HDC bmpdc = CreateCompatibleDC(dc);

	LOGBRUSH lbrush;
	lbrush.lbColor = RGB(0,0,0);
	lbrush.lbHatch = 0;
	lbrush.lbStyle = BS_SOLID;
	
	HBRUSH brush = CreateBrushIndirect(&lbrush);
	HPEN pen = CreatePen(PS_NULL, 0, 0);

	HGDIOBJ oldbmp = SelectObject(bmpdc, bmp);
	HGDIOBJ oldbmppen = SelectObject(bmpdc, pen);
	HGDIOBJ oldbmpbrush = SelectObject(bmpdc, brush);
	HGDIOBJ oldbmpfont = SelectObject(bmpdc, font);

	SetTextColor(bmpdc, RGB(255,255,255));

	Rectangle(bmpdc, 0,0,surfaceWidth,surfaceHeight);
	SetBkMode(bmpdc, TRANSPARENT);

	SCharData* d;
	BOOL bShift=TRUE;//(GetAsyncKeyState(VK_SHIFT)<0);
	DWORD dwShiftColor=RGB(0,255,0);
	DWORD dwRTColor=RGB(0,0,255);
	DWORD dwRBColor=RGB(255,0,0);
	if(bXml){
		dwRTColor=dwShiftColor;
		dwRBColor=dwShiftColor;
	}
	for (i=0; i<characterCount; ++i)
	{
		d = &asciiTable[i];
		if(bShift){
			for(int kk=0;kk<d->cwidth;kk++){
				SetPixel(bmpdc, d->posX+kk, d->posY, dwShiftColor);
				SetPixel(bmpdc, d->posX+kk, d->posY+ d->cheight, dwShiftColor);
			}
			for(int kk2=0;kk2<d->cheight;kk2++){
				SetPixel(bmpdc, d->posX, d->posY+kk2, dwShiftColor);
				SetPixel(bmpdc, d->posX+d->cwidth, d->posY+kk2, dwShiftColor);
			}
		}
		if(isUnused(iCharset,d->character)<=0){
			//TextOutW(bmpdc, d->posX+gapx-d->abcA, d->posY+gapy, &d->character, 1);
			SetTextAlign(bmpdc,TA_CENTER|TA_TOP);
			TextOutW(bmpdc, d->posX+(d->cwidth+0)/2+(-d->abcA+d->abcC)*0.5, d->posY+gapy, &d->character, 1);//

			WCHAR wct[2]={0};
			wct[0]=d->character;
			sXML+=toString("<char code='%i' ascii='%i' sym='%s' l='%i' t='%i' r='%i' b='%i' abcA='%i' abcB='%i' abcC='%i'/>\n",d->character,d->askiiCode,W2A(wct),d->posX+1, d->posY+1,d->posX+ d->cwidth -1-1, d->posY + d->cheight-1,d->abcA,d->abcB,d->abcC);		
		
		}
		SetPixel(bmpdc, d->posX, d->posY, dwRTColor);// left upper corner mark
		SetPixel(bmpdc, d->posX+ d->cwidth -1, d->posY + d->cheight, dwRBColor);// right lower corner mark
	}

	// draw index pixels
	SetPixel(bmpdc, 0,0, dwRTColor); // left upper corner mark
	SetPixel(bmpdc, 1,0, dwRBColor); // right lower corner mark
	SetPixel(bmpdc, 2,0, dwShiftColor); // right lower corner mark
	SetPixel(bmpdc, 3,0, RGB(0,0,0)); // background color mark

	char szDir[MAX_PATH]="";//"F://";
	char szFint[256]={0};
	if(bXml){
		sprintf(szFint,"%s%s_(%s_%i_%ix%i_%i_%i)",szDir,szTextureName,str,surfaceWidth,gapx,gapy,fontSize,iCharset);
		//SaveBitmapToDisk(bmp,szFint,0);
		sXML+="</font>\n";
		char szFintXml[256]={0};
		sprintf(szFintXml,"%s.xml",szFint);
		DeleteFile(szFintXml);
		SaveFile(szFintXml,sXML);
		char szFintBml[256]={0};
		sprintf(szFintBml,"%s%s.bmp",szDir,szTextureName);
		DeleteFile(szFintBml);
		SaveBitmapToDisk(bmp,szFintBml,hWnd);
	}
	//ANSI_CHARSET
	OpenClipboard(hWnd);
	EmptyClipboard();
	SetClipboardData(CF_BITMAP, bmp);
	CloseClipboard();

	SelectObject(bmpdc, oldbmp);
	SelectObject(bmpdc, oldbmppen);
	SelectObject(bmpdc, oldbmpbrush);
	SelectObject(bmpdc, oldbmpfont);

	SelectObject(dc, oldfont);
	ReleaseDC(preview, dc);

	DeleteDC(bmpdc);
	DeleteObject(font);
	DeleteObject(brush);
	DeleteObject(pen);
	DeleteObject(bmp);
	if(szFint[0]){
		char szTeee[240]={0};
		sprintf(szTeee,"Done, Saved to %s",szFint);
		AfxMessageBox(szTeee);
	}
}


BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) 
	{
	case WM_INITDIALOG:
		return TRUE;
	case WM_COMMAND:
		{
			int wNotifyCode = HIWORD(wParam);
			int wID = LOWORD(wParam);
			HWND hwndCtl = (HWND)lParam;

			switch(wID)
			{
			case IDOK:
			case IDCANCEL:
				EndDialog(hwndDlg, wNotifyCode);
				PostQuitMessage(0);
				return TRUE;
			case IDC_CHECK1:
			case IDC_CHECK2:
			case IDC_LIST1:
			case IDC_EDIT_SIZE: 
				updateFontPreview(hwndDlg);
				return TRUE;
			case IDC_BUTTON2:
				MessageBox(hwndDlg, "IrrFontTool version 1.1 (c) 2003-2005 by N.Gebhardt.\n\n"\
					"This tools creates bitmap fonts for using them with the Irrlicht Engine.\n"\
					"You can download the Engine and (newer) versions of this tool from "\
					"http://irrlicht.sourceforge.net.",
					"About IrrFontTool", MB_OK | MB_ICONINFORMATION);
				return TRUE;
			case IDC_BUTTON1:
				copyFontToClipBoard(hwndDlg, 256);//381???
				return TRUE;
			}
		}
		break;
	}

	return FALSE;
}


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow )
{
	HWND hWnd = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), 0, DialogProc);

	ShowWindow(hWnd , SW_SHOW);

	FillFontList(hWnd);

	MSG msg;
	do
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}else{
			Sleep(100);
		}
	}
	while (msg.message != WM_QUIT);

	return 0;
}



